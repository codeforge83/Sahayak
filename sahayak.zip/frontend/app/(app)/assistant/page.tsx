'use client';

import { Suspense, useEffect, useRef } from 'react';
import { useSearchParams } from 'next/navigation';
import { ChatUpload, MessageBubble, PromptBox, SuggestedQuestions } from '@/components/assistant';
import { Icon } from '@/components/common';
import { useAskAssistant, useDocuments, useTranslation } from '@/hooks';
import { useChatStore, useWorkspaceStore } from '@/store';

function AssistantScreen() {
  const params = useSearchParams();
  const { t, tr } = useTranslation();
  const ask = useAskAssistant();
  const { messages, pending } = useChatStore();
  const { data: documents } = useDocuments();
  const activeDocumentId = useWorkspaceStore((s) => s.activeDocumentId);
  const activeDoc = documents?.find((d) => d.id === activeDocumentId);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, pending]);

  return (
    <div className="flex min-h-full flex-col">
      <header className="mb-4">
        <h1 className="text-2xl font-bold">{t('askTitle')}</h1>
        <p className="mt-2 text-lg leading-relaxed text-muted">{t('askSub')}</p>
      </header>

      <div className="flex-1 space-y-3">
        {messages.length === 0 && (
          <div className="rounded-xl2 border border-navy-100 bg-white p-4 shadow-soft">
            <p className="text-base leading-relaxed">{t('askGreeting')}</p>
          </div>
        )}

        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}

        {pending && (
          <div className="flex justify-start">
            <div className="rounded-2xl border border-navy-100 bg-white px-4 py-3 text-base text-muted shadow-soft">
              {t('loading')}
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="sticky bottom-0 mt-4 space-y-3 bg-paper pb-1 pt-2">
        {messages.length === 0 && <SuggestedQuestions onPick={(q) => ask.mutate(q)} />}
        {activeDoc && (
          <div className="flex items-center gap-2 rounded-xl border border-navy-100 bg-navy-50 px-3 py-2 text-sm text-navy-700">
            <Icon name="doc" className="h-4 w-4 shrink-0" />
            <span className="font-semibold">{t('aboutDoc')}</span>
            <span className="min-w-0 flex-1 truncate">{tr(activeDoc.title)}</span>
          </div>
        )}
        <div className="flex items-center justify-start">
          <ChatUpload />
        </div>
        <PromptBox
          onSend={(question) => ask.mutate(question)}
          disabled={pending}
          autoListen={params.get('listen') === '1'}
        />
      </div>
    </div>
  );
}

export default function AssistantPage() {
  return (
    <Suspense fallback={null}>
      <AssistantScreen />
    </Suspense>
  );
}
