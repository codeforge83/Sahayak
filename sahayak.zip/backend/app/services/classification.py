"""
Classify an uploaded file: what kind of document is it, is it a government
document at all, and how confident are we.

This drives two things the reader sees. First, wrong-document detection — a
restaurant bill or a holiday photo should get a friendly "this is not a
government document", never a wall of OCR. Second, checklist matching — a
document's detected type is what lets an uploaded Aadhaar tick the "Aadhaar
Card" box on a pension notice.

It is intentionally conservative. An uncertain result says so rather than
inventing a type, because a wrong classification is worse than an honest
"I couldn't tell".
"""

import re

# A known government document type: (keywords, human name, checklist tags).
# `tags` are the tokens a requirement line is matched against.
GOV_TYPES: list[tuple[tuple[str, ...], str, tuple[str, ...]]] = [
    (("permanent account number", "income tax department", "pan card"), "PAN Card", ("pan",)),
    (
        ("aadhaar", "aadhar", "unique identification", "uidai", "आधार", "ఆధార్"),
        "Aadhaar Card",
        ("aadhaar", "aadhar"),
    ),
    # Pension is checked before life certificate, so a pension notice that
    # merely mentions "life certificate" as a requirement is still a pension
    # document — not a life certificate itself.
    (("pension", "ppo", "pensioner"), "Pension Document", ("pension",)),
    (
        ("life certificate", "jeevan pramaan"),
        "Life Certificate",
        ("life certificate", "jeevan pramaan"),
    ),
    (("income certificate",), "Income Certificate", ("income certificate", "income")),
    (
        ("caste certificate", "community certificate"),
        "Caste Certificate",
        ("caste", "community"),
    ),
    (
        ("residence certificate", "domicile certificate", "residential certificate"),
        "Residence Certificate",
        ("residence", "domicile"),
    ),
    (("birth certificate",), "Birth Certificate", ("birth certificate",)),
    (("death certificate",), "Death Certificate", ("death certificate",)),
    (("ration card",), "Ration Card", ("ration",)),
    (("driving licence", "driving license"), "Driving Licence", ("driving licence", "licence")),
    (("passport",), "Passport", ("passport",)),
    (
        ("voter", "electoral", "epic no", "election commission"),
        "Voter ID",
        ("voter", "epic"),
    ),
    (
        ("bank passbook", "passbook", "account number", "ifsc"),
        "Bank Passbook",
        ("bank passbook", "passbook", "bank"),
    ),
]

# Signals that a document is NOT a government document.
_NON_GOV = (
    "restaurant",
    "cafe",
    "menu",
    "invoice",
    "gst invoice",
    "tax invoice",
    "bill no",
    "subtotal",
    "grand total",
    "qty",
    "quantity",
    "thank you for dining",
    "thank you for shopping",
    "order id",
    "cart",
    "checkout",
    "delivery",
    "boarding pass",
    "ticket",
)

# General signals that a document IS official.
_GOV_HINTS = (
    "government",
    "govt",
    "certificate",
    "department",
    "tahsildar",
    "mandal",
    "municipal",
    "corporation",
    "registrar",
    "gazette",
    "sub-registrar",
    "revenue",
    "sachivalayam",
    "meeseva",
    "mee seva",
    "telangana",
    "andhra pradesh",
    "government of india",
)

_PAN_RE = re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")
_AADHAAR_RE = re.compile(r"\b\d{4}\s\d{4}\s\d{4}\b")


def classify_document(raw_text: str | None) -> dict:
    """Return {docType, tags, isGovernment, confidence} for the extracted text."""
    text = (raw_text or "").strip()
    lowered = text.lower()

    # Too little readable text to judge.
    if len(text) < 25:
        return {
            "docType": "",
            "tags": [],
            "isGovernment": False,
            "confidence": 0.2,
        }

    # A known government type is the strongest signal.
    for keywords, name, tags in GOV_TYPES:
        if any(k in lowered for k in keywords):
            return {
                "docType": name,
                "tags": list(tags),
                "isGovernment": True,
                "confidence": 0.9,
            }

    gov_hits = sum(1 for h in _GOV_HINTS if h in lowered)
    non_gov_hits = sum(1 for s in _NON_GOV if s in lowered)
    has_id = bool(_PAN_RE.search(text) or _AADHAAR_RE.search(text))

    if has_id or gov_hits >= 2:
        return {
            "docType": "Government document",
            "tags": [],
            "isGovernment": True,
            "confidence": 0.7 if gov_hits < 3 else 0.85,
        }

    # Looks like something else entirely.
    if non_gov_hits >= 2 and gov_hits == 0:
        guess = "receipt" if any(w in lowered for w in ("invoice", "bill", "total")) else ""
        return {
            "docType": guess or "non-government document",
            "tags": [],
            "isGovernment": False,
            "confidence": 0.7,
        }

    # A single official hint: probably a document, but say so weakly.
    if gov_hits == 1:
        return {"docType": "", "tags": [], "isGovernment": True, "confidence": 0.5}

    # Nothing to go on.
    return {"docType": "", "tags": [], "isGovernment": False, "confidence": 0.3}
