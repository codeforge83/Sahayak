/* SAHAYAK service worker.
   Purpose: the app must open on a phone with no signal. Someone standing in
   a queue outside a government office should still be able to read their
   deadline and shrink a photo.

   Strategy: cache first, network second, and quietly add anything new to the
   cache as it is fetched — including the CDN copies of React and Tailwind,
   which is what makes a genuinely offline second launch possible. */

const CACHE = 'sahayak-v1';

const CORE = ['/', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE)
      .then((c) => Promise.all(CORE.map((u) => c.add(u).catch(() => {}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith(
    caches.match(req).then((hit) => {
      if (hit) return hit;
      return fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy).catch(() => {}));
          return res;
        })
        .catch(() =>
          /* Offline and not in the cache. For a page request, hand back the
             app itself rather than the browser's dinosaur. */
          req.mode === 'navigate' ? caches.match('/') : Response.error()
        );
    })
  );
});
