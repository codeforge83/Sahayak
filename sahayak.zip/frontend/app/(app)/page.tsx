'use client';

import {
  AppFooter,
  FeatureList,
  HeroActions,
  HowItWorks,
  LanguageLadder,
  PrivacyNote,
} from '@/components/home';

export default function HomePage() {
  return (
    <>
      <div className="space-y-8">
        <HeroActions />
        <LanguageLadder />
        <HowItWorks />
        <FeatureList />
        <PrivacyNote />
      </div>
      <AppFooter />
    </>
  );
}
