'use client';

import { Icon } from '@/components/common';
import { useTranslation } from '@/hooks';
import type { StringKey } from '@/lib/i18n';

const STEPS: { icon: string; key: StringKey }[] = [
  { icon: 'upload', key: 'how1t' },
  { icon: 'spark', key: 'how2t' },
  { icon: 'info', key: 'how3t' },
  { icon: 'tasks', key: 'how4b' },
  { icon: 'check', key: 'how5b' },
  { icon: 'search', key: 'how6t' },
];

/** The Sahayak workflow, one clear step at a time. */
export function HowItWorks() {
  const { t } = useTranslation();

  return (
    <section aria-labelledby="how-heading">
      <h2 id="how-heading" className="mb-4 text-2xl font-bold">
        {t('howTitle')}
      </h2>
      <ol className="space-y-2.5">
        {STEPS.map((step, index) => (
          <li
            key={step.key}
            className="flex items-center gap-3.5 rounded-xl2 border border-navy-100 bg-white p-4 shadow-soft"
          >
            <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-navy-50 text-navy-600">
              <Icon name={step.icon} className="h-6 w-6" />
              <span className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-navy-600 text-xs font-bold text-white">
                {index + 1}
              </span>
            </span>
            <span className="text-lg font-semibold leading-snug">{t(step.key)}</span>
          </li>
        ))}
      </ol>
    </section>
  );
}
