'use client';

import { useRouter } from 'next/navigation';
import { EmptyState } from '@/components/common';
import { DocumentCard } from '@/components/documents';
import { Skeleton } from '@/components/ui';
import { useDeleteDocument, useDocuments, useTranslation } from '@/hooks';
import { useUiStore } from '@/store';

/** A plain personal document locker — every file the reader has added, newest first. */
export default function DocumentsPage() {
  const router = useRouter();
  const { t } = useTranslation();
  const { data: documents, isLoading } = useDocuments();
  const remove = useDeleteDocument();
  const setDirection = useUiStore((s) => s.setDirection);

  const docs = documents ?? [];

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold">{t('docsTitle')}</h1>
        <p className="mt-2 text-lg text-muted">{t('docsSub')}</p>
      </header>

      {isLoading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : docs.length === 0 ? (
        <EmptyState
          icon="folder"
          title={t('noDocs')}
          actionLabel={t('addDoc')}
          onAction={() => {
            setDirection('push');
            router.push('/upload');
          }}
        />
      ) : (
        <div className="space-y-3">
          {docs.map((doc) => (
            <DocumentCard
              key={doc.id}
              document={doc}
              onDelete={(id) => {
                if (window.confirm(t('removeAsk'))) remove.mutate(id);
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
