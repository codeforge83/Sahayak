'use client';

import { useRouter } from 'next/navigation';
import { ActionGroup } from '@/components/actions';
import { Icon } from '@/components/common';
import { Skeleton } from '@/components/ui';
import { useChecklists, useDocuments, useTranslation } from '@/hooks';
import { GOV_SERVICES } from '@/lib/data/gov-services';
import { matchRequirement } from '@/lib/requirement-match';
import { useUiStore } from '@/store';

export default function ActionsPage() {
  const router = useRouter();
  const { t, tr } = useTranslation();
  const { data: documents, isLoading } = useDocuments();
  const { data: checklists } = useChecklists();
  const setDirection = useUiStore((s) => s.setDirection);

  const docs = documents ?? [];
  const actionable = docs.filter((d) => d.status === 'action' && d.steps.length > 0);

  const open = (href: string) => {
    setDirection('push');
    router.push(href);
  };

  return (
    <div className="space-y-6">
      {/* Government services as workflows. */}
      <section aria-labelledby="services-heading">
        <header className="mb-4">
          <h1 id="services-heading" className="text-2xl font-bold">
            {t('actServicesTitle')}
          </h1>
          <p className="mt-2 text-lg leading-relaxed text-muted">{t('actServicesSub')}</p>
        </header>

        <div className="space-y-2.5">
          {GOV_SERVICES.map((service) => {
            const total = service.documents.length;
            const ready = service.documents.filter((r) => matchRequirement(r.en, docs)).length;
            return (
              <button
                key={service.id}
                type="button"
                onClick={() => open(`/services/${service.id}`)}
                className="flex w-full items-center gap-3.5 rounded-xl2 border border-navy-100 bg-white p-4 text-left shadow-soft active:bg-navy-50"
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-navy-50 text-navy-600">
                  <Icon name={service.icon} className="h-6 w-6" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-lg font-bold leading-snug">{tr(service.title)}</span>
                  <span className="mt-0.5 block text-sm text-muted">
                    {ready} {t('of')} {total} {t('svcReadyCount')}
                  </span>
                </span>
                <span className="shrink-0 rounded-full bg-navy-50 px-3 py-1.5 text-sm font-semibold text-navy-700">
                  {t('svcOpen')}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Outstanding steps gathered from the reader's own documents. */}
      {isLoading ? (
        <Skeleton className="h-40 w-full" />
      ) : actionable.length > 0 ? (
        <section aria-labelledby="tasks-heading">
          <h2 id="tasks-heading" className="mb-4 text-2xl font-bold">
            {t('actDocTasks')}
          </h2>
          <div className="space-y-4">
            {actionable.map((doc) => (
              <ActionGroup key={doc.id} document={doc} checklist={checklists?.[doc.id]} />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
