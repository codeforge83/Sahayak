'use client';

import { useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Button, Skeleton } from '@/components/ui';
import { Icon } from '@/components/common';
import {
  DocumentHeader,
  DocumentSummary,
  EligibilityChecker,
  ExplanationSections,
  JargonPairs,
  OriginalFile,
  OriginalWording,
  PersonalDetails,
  RelevantServices,
  StepChecklist,
} from '@/components/document';
import { useChecklists, useDocument, useTranslation } from '@/hooks';
import { useUiStore, useWorkspaceStore } from '@/store';

/**
 * One document, explained. The reader lands on a calm summary — what it is,
 * what to do, the last date, the papers needed — and only sees the full
 * breakdown, the raw notice and the reference numbers after choosing Continue.
 */
export default function DocumentDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { t } = useTranslation();
  const id = params.id;

  const { data: document, isLoading, isError } = useDocument(id);
  const { data: checklists } = useChecklists();
  const setActiveDocumentId = useWorkspaceStore((s) => s.setActiveDocumentId);
  const setDirection = useUiStore((s) => s.setDirection);

  const [showDetails, setShowDetails] = useState(false);
  const detailsRef = useRef<HTMLDivElement>(null);

  // So the assistant knows what "this document" means.
  useEffect(() => {
    setActiveDocumentId(id);
    return () => setActiveDocumentId(null);
  }, [id, setActiveDocumentId]);

  // Reset to the summary whenever a different document is opened.
  useEffect(() => setShowDetails(false), [id]);

  const openDetails = () => {
    setShowDetails(true);
    requestAnimationFrame(() =>
      detailsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }),
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (isError || !document) {
    return <p className="rounded-xl2 bg-alert-50 p-5 text-lg text-alert-600">{t('notFound')}</p>;
  }

  return (
    <div className="space-y-5">
      <DocumentSummary document={document} onContinue={openDetails} />

      {showDetails && (
        <div ref={detailsRef} className="animate-rise space-y-5 border-t border-navy-100 pt-6">
          <DocumentHeader document={document} />
          <OriginalFile document={document} />
          <PersonalDetails document={document} />
          <ExplanationSections document={document} />
          <RelevantServices document={document} />
          <StepChecklist document={document} checklist={checklists?.[document.id]} kind="steps" />
          <StepChecklist document={document} checklist={checklists?.[document.id]} kind="need" />
          <EligibilityChecker document={document} />
          <JargonPairs document={document} />
          <OriginalWording document={document} />

          <div className="space-y-2.5 pb-4">
            {(document.status === 'action' ||
              !!document.deadline ||
              (document.need?.length ?? 0) > 0) && (
              <Button
                full
                size="md"
                variant="secondary"
                onClick={() => {
                  setDirection('push');
                  router.push(`/mee-seva?doc=${document.id}`);
                }}
              >
                <Icon name="scan" className="h-5 w-5" />
                {t('meeFindForDoc')}
              </Button>
            )}
            <Button
              full
              size="md"
              onClick={() => {
                setDirection('push');
                router.push(`/documents/${document.id}/plan`);
              }}
            >
              <Icon name="tasks" className="h-5 w-5" />
              {t('goActions')}
            </Button>
            <Button
              full
              size="md"
              variant="secondary"
              onClick={() => {
                setDirection('push');
                router.push('/assistant');
              }}
            >
              <Icon name="chat" className="h-5 w-5" />
              {t('askAbout')}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
